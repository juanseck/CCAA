%  Continuous Cellular Automata Algorithm (CCAA)
%
%  Source codes demo version 1.0
%
%  Developed in MATLAB R2015a(7.08)
%
%  Author and programmer: Juan Carlos Seck Tuoh Mora
%
%       email:   jseck@uaeh.edu.mx
%                juanseck@gmail.com
%
%       Homepage:
%
%  Main paper: A continuous cellular automata algorithm for global optimization 
%  Autores: Juan Carlos Seck-Tuoh-Mora, Norberto Hernandez-Romero, Pedro
%  Lagos-Eulogio, Joselito Medina-Marin, Nadia Samantha Zuñiga-Peña
%  Expert Systems With Applications, DOI: http://
%_______________________________________________________________________________________________
% You can simply define your cost function in a seperate file and load its handle to fobj
% The initial parameters that you need are:
%__________________________________________
% SmartCells_no = number of smart-cells
% Neighbors_no = number of neighbors
% Max_iteration = maximum number of iterations
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% dim = number of variables to be tunned
% fobj = @YourCostFunction
%
% If all the variables have equal lower bound you can just
% define lb and ub as two single numbers
%
% To run RCAA: [min_value,position_vector,convergence_curve]=RCA(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,fobj)
%______________________________________________________________________________________________

clear all
clc

SmartCells_no=12;     % Number of smart-cells
Neighbors_no=6;        % Number of neighbors for each smart-cell
Max_iteration=500;    % Maximum numbef of iterations
Function_name='F1';  % Name of the test function that can be from F1 to F23  checar performance F5 F9, ojo F15, ojo F17 no corre
Solution_no=SmartCells_no*Neighbors_no;

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=benchmark_functions(Function_name);
%dim=500;

% Execute optimization algorithm
%Algoritmo CCAA
[min_value,position_vector,convergence_curve]=CCAA(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,fobj);

figure(1)
if sum(convergence_curve<0) >0
    plot(1:Max_iteration,convergence_curve,'-s','Color','r','LineWidth',1.5,'MarkerSize',10,'MarkerIndices',1:50:Max_iteration)
else
    semilogy(1:Max_iteration,convergence_curve,'-s','Color','r','LineWidth',1.5,'MarkerSize',10,'MarkerIndices',1:50:Max_iteration)
end
legend('CCAA')
title(Function_name,'Fontsize',14)
xlabel('Iterations','Fontsize',13);
ylabel('Best fitness','Fontsize',13);
axis tight

display(['The best optimal value of the objective funciton found by CCAA is : ', num2str(min_value)]);

