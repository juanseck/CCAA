%  Continuous Cellular Automata Algorithm (CCAA)
%
%  Source codes demo version 1.0
%
%  Developed in MATLAB R2015a(7.08)
%
%  Author and programmer: Juan Carlos Seck Tuoh Mora
%
%       email:   jseck@uaeh.edu.mx
%                juanseck@gmail.com
%
%       Homepage:
%
%  Main paper: A continuous cellular automata algorithm for global optimization 
%  Autores: Juan Carlos Seck-Tuoh-Mora, Norberto Hernandez-Romero, Pedro
%  Lagos-Eulogio, Joselito Medina-Marin, Nadia Samantha Zuñiga-Peña
%  Expert Systems With Applications, DOI: http://
%_______________________________________________________________________________________________
% The initial parameters that you need are:
%__________________________________________
% SmartCells_no = number of smart-cells
% Neighbors_no = number of neighbors
% Max_iteration = maximum number of iterations
% Load details:
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% dim = number of variables to be tunned
% fobj = @YourCostFunction
%
%
%______________________________________________________________________________________________

%   Eaxmples:
%
%   Gear train design
%   Gear
%   Gupta, S., Deep, K., Mirjalili, S., & Kim, J. H. (2020). A Modified Sine Cosine Algorithm with Novel Transition
%   Parameter and Mutation Operator for Global Optimization. Expert Systems with Applications, 113395.
%
%
%   PVD problem
%   PVD
%   Chen, H., Yang, C., Heidari, A. A., & Zhao, X. (2020). An efficient double adaptive random spare reinforced
%   whale optimization algorithm. Expert Systems with Applications, 154, 113018.
%   [0.793769 0.39236 41.127973 189.045124] de RDWOA No cumple 3 restricciones 35912
%   [0.81250 0.43750 42.0984 176.6366] de MSCA No cumple 1 restricciones 16059
%
%
%
%   Welded beam design (Coello, 2000)
%   WBD
%   Gupta, S., Deep, K., Mirjalili, S., & Kim, J. H. (2020). A Modified Sine Cosine Algorithm with Novel Transition
%   Parameter and Mutation Operator for Global Optimization. Expert Systems with Applications, 113395.
%   [0.205618 3.252958 9.04447 0.20569] de RDWOA no cumple restricciones 1 y 7



clear all
num_trabajadores=50;    % Para prueba paralela

SmartCells_no=20;       % Number of smart-cells
Neighbors_no=5;        % Number of neighbors for each smart-cell
Max_iteration=500;      % Maximum numbef of iterations
Function_name='PVD';   % Name of the test application function that can be from: Gear, PVD, WBD, CAN, IIR#, IIR#R, con # de 1 a 5
[lb,ub,dim,fobj]=Application_functions(Function_name);

% SmartCells_no=10;       % Number of smart-cells
% Neighbors_no=6;        % Number of neighbors for each smart-cell
% Max_iteration=500;      % Maximum numbef of iterations
% Function_name='F24';   % Name of the benchmark test function that can be from: F1 to F33
% [lb,ub,dim,fobj] = benchmark_functions(Function_name);
%dim=500;


% Execute optimization algorithm

%Algoritmo propuesto CCAA
%Se hizo version entera usando round
if strcmp(Function_name,'Gear')
    for i=1:num_trabajadores
        [arreglo_minimos(i),arreglo_posiciones(i,:),arreglo_convergencia(i,:)]=CCAAentero(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,fobj);
    end
elseif strcmp(Function_name,'PVD')
    for i=1:num_trabajadores
        [arreglo_minimos(i),arreglo_posiciones(i,:),arreglo_convergencia(i,:)]=CCAAenteroSelectivo(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,[1 2],fobj);
    end
else
    for i=1:num_trabajadores
        [arreglo_minimos(i),arreglo_posiciones(i,:),arreglo_convergencia(i,:),poblacion(:,:,i)]=CCAA5(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,fobj);
    end
end
promedio=mean(arreglo_minimos);
[~,ind_min] = min(arreglo_minimos);

display(['The best solution obtained by CCAA is : ', num2str(arreglo_posiciones(ind_min,:))]);
display(['The best optimal value of the objective funciton found by CCAA is : ', num2str(arreglo_minimos(ind_min))]);
display(['The average optimal value of the objective funciton found by CCAA is : ', num2str(promedio)]);
