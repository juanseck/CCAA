%  Continuous Cellular Automata Algortihm (CCAA)  
%
%  Developed in MATLAB R2015a(7.08)                                                                   
%                                                                                                     
%  Author and programmer: Juan Carlos Seck Tuoh Mora
%                                                                                                     
%       email:   jseck@uaeh.edu.mx
%                    juanseck@gmail.com                                                             
%                                                                                                     
%       Homepage: 
%                                                                                                     
%  Main paper:                                                                                        
%  Autores, CCAA: A Continuous Cellular Automata Algorithm for solving global optimization problems
%  Expert Systems With Applications, DOI: http://
%
% This function containts full information and implementations of the engineering problems 
% functions from the literature 
%
% lb is the lower bound: lb=[lb_1,lb_2,...,lb_d]
% up is the uppper bound: ub=[ub_1,ub_2,...,ub_d]
% dim is the number of variables (dimension of the problem)

function [lb,ub,dim,fobj] = Application_functions(F)


switch F
    case 'Gear'
        fobj = @Gear;
        lb=12;
        ub=60;
        dim=4;
        
    case 'PVD'
        fobj = @PVD;
        lb=[0 0 10 10];
        ub=[99 99 200 200];
        dim=4;    
    
    case 'WBD'
        fobj = @WBD;
        lb=[0.1 0.1 0.1 0.1];
        ub=[2 10 10 2];
        dim=4;
        
    case 'CAN'
        fobj = @CAN;
        lb=0.01;
        ub=100;
        dim=5;
        
    case 'IIR1'
        fobj = @IIR1;
        lb=-2.048;
        ub=2.048;
        dim=4;
        
    case 'IIR1R'
        fobj = @IIR1R;
        lb=-2.048;
        ub=2.048;
        dim=2;
        
    case 'IIR2'
        fobj = @IIR2;
        lb=-2.048;
        ub=2.048;
        dim=6;
        
    case 'IIR2R'
        fobj = @IIR2R;
        lb=-2.048;
        ub=2.048;
        dim=4;
        
    case 'IIR3'
        fobj = @IIR3;
        lb=-2.048;
        ub=2.048;
        dim=8;
        
    case 'IIR3R'
        fobj = @IIR3R;
        lb=-2.048;
        ub=2.048;
        dim=6;
        
    case 'IIR4'
        fobj = @IIR4;
        lb=-2.048;
        ub=2.048;
        dim=11;
        
    case 'IIR4R'
        fobj = @IIR4R;
        lb=-2.048;
        ub=2.048;
        dim=9;
        
    case 'IIR5'
        fobj = @IIR5;
        lb=-2.048;
        ub=2.048;
        dim=7;
        
    case 'IIR5R'
        fobj = @IIR5R;
        lb=-2.048;
        ub=2.048;
        dim=11;
end

end

% Gear

function o = Gear(x)
o=((1/6.931)-((x(2)*x(3))/((x(1)*x(4)))))^2;
end

% PVD

function o = PVD(x)
o=(0.6224*x(1)*x(3)*x(4))+(1.7781*x(2)*x(3)^2)+(3.1661*x(4)*x(1)^2)+(19.84*x(3)*x(1)^2);
res1=(-x(1)+(0.0193*x(3)));
if res1 > 0
    o=o+10000;
end
res2=(-x(2)+(0.00954*x(3)));
if  res2 > 0
    o=o+10000;
end
res3=((-pi*x(4)*x(3)^2)-((4/3)*pi*x(3)^3)+(1296000));
if  res3 > 0
    o=o+10000;
end
res4=(x(4)-(240));
if  res4 > 0
    o=o+10000;
end
end

% Welded beam design WBD

function o = WBD(x)
P = 6000; % APPLIED TIP LOAD
E = 30e6; % YOUNGS MODULUS OF BEAM
G = 12e6; % SHEAR MODULUS OF BEAM
L = 14; % LENGTH OF CANTILEVER PART OF BEAM
PCONST = 1000000; % PENALTY FUNCTION CONSTANT
TAUMAX = 13600; % MAXIMUM ALLOWED SHEAR STRESS
SIGMAX = 30000; % MAXIMUM ALLOWED BENDING STRESS
DELTMAX = 0.25; % MAXIMUM ALLOWED TIP DEFLECTION
M = P*(L+x(2)/2); % BENDING MOMENT AT WELD POINT
R = sqrt((x(2)^2)/4+((x(1)+x(3))/2)^2); % SOME CONSTANT
J = 2*(sqrt(2)*x(1)*x(2)*((x(2)^2)/12+((x(1)+x(3))/2)^2)); % POLAR MOMENT OF INERTIA
OBJ = 1.10471*x(1)^2*x(2)+0.04811*x(3)*x(4)*(14+x(2)); % OBJECTIVE FUNCTION
SIGMA = (6*P*L)/(x(4)*x(3)^2); % BENDING STRESS
DELTA = (4*P*L^3)/(E*x(4)*x(3)^3); % TIP DEFLECTION
PC = 4.013*E*sqrt((x(3)^2*x(4)^6)/36)*(1-x(3)*sqrt(E/(4*G))/(2*L))/(L^2); % BUCKLING LOAD
TAUP = P/(sqrt(2)*x(1)*x(2)); % 1ST DERIVATIVE OF SHEAR STRESS
TAUPP = (M*R)/J; % 2ND DERIVATIVE OF SHEAR STRESS
TAU = sqrt(TAUP^2+2*TAUP*TAUPP*x(2)/(2*R)+TAUPP^2); % SHEAR STRESS
G1 = TAU-TAUMAX; % MAX SHEAR STRESS CONSTRAINT
% if G1>0
%     disp('No cumple 1')
% end

G2 = SIGMA-SIGMAX; % MAX BENDING STRESS CONSTRAINT
% if G2>0
%     disp('No cumple 2')
% end

G3 = x(1)-x(4); % WELD COVERAGE CONSTRAINT
% if G3>0
%     disp('No cumple 3')
% end

G4 = 0.10471*x(1)^2+0.04811*x(3)*x(4)*(14+x(2))-5; % MAX COST CONSTRAINT
% if G4>0
%     disp('No cumple 4')
% end

G5 = 0.125-x(1); % MAX WELD THICKNESS CONSTRAINT
% if G5>0
%     disp('No cumple 5')
% end

G6 = DELTA-DELTMAX; % MAX TIP DEFLECTION CONSTRAINT
% if G6>0
%     disp('No cumple 6')
% end

G7 = P-PC; % BUCKLING LOAD CONSTRAINT
% if G7>0
%     disp('No cumple 7')
% end

o = OBJ + PCONST*(max(0,G1)^2+max(0,G1)^2+max(0,G2)^2+...
    max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+...
    max(0,G6)^2+max(0,G7)^2); % PENALTY FUNCTION

end

% Camtilever  CAN

function o=CAN(X)
x1=X(1);
x2=X(2);
x3=X(3);
x4=X(4);
x5=X(5);

if  61/(x1^3)+37/(x2^3)+19/(x3^3)+7/(x4^3)+1/(x5^3)-1<=0
    
    o=0.0624*(x1+x2+x3+x4+x5);
    
else
    
    o=200000;
    
end
end

function o=IIR1(X)
D_opt=[0.05 -0.4 -1.1314 0.25];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2)],[1 D_opt(3) D_opt(4)],u1);
F_est=filter([X(1) X(2)],[1 X(3) X(4)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR1R(X)
D_opt=[0.05 -0.4 -1.1314 0.25];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2)],[1 D_opt(3) D_opt(4)],u1);
F_est=filter(X(1),[1 X(2)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR2(X)
D_opt=[-0.20 -0.40 0.50 -0.60 0.250 -0.20];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2) D_opt(3)],[1 D_opt(4) D_opt(5) D_opt(6)],u1);
F_est=filter([X(1) X(2) X(3)],[1 X(4) X(5) X(6)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR2R(X)
D_opt=[-0.20 -0.40 0.50 -0.60 0.250 -0.20];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2) D_opt(3)],[1 D_opt(4) D_opt(5) D_opt(6)],u1);
F_est=filter([ X(1) X(2)],[1 X(3) X(4)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR3(X)
D_opt=[1.0000 -0.9000 0.8100 -0.7290 0.0400 0.2775 -0.2101 0.1400];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2) D_opt(3) D_opt(4)],[1 D_opt(5) D_opt(6) D_opt(7) D_opt(8)],u1);
F_est=filter([X(1) X(2) X(3) X(4)],[1 X(5) X(6) X(7) X(8)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR3R(X)
D_opt=[1.0000 -0.9000 0.8100 -0.7290 0.0400 0.2775 -0.2101 0.1400];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2) D_opt(3) D_opt(4)],[1 D_opt(5) D_opt(6) D_opt(7) D_opt(8)],u1);
F_est=filter([X(1) X(2) X(3)],[1 X(4) X(5) X(6)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR4(X)
D_opt=[0.1084 0.5419 1.0837 1.0837 0.5419 0.1084 0.9853 0.9738 0.3864 0.1112 0.0113];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2) D_opt(3) D_opt(4) D_opt(5) D_opt(6)],[1  D_opt(7) D_opt(8) D_opt(9) D_opt(10) D_opt(11)],u1);
F_est=filter([X(1) X(2) X(3) X(4) X(5) X(6)],[1  X(7) X(8) X(9) X(10) X(11)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR4R(X)
D_opt=[0.1084 0.5419 1.0837 1.0837 0.5419 0.1084 0.9853 0.9738 0.3864 0.1112 0.0113];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) D_opt(2) D_opt(3) D_opt(4) D_opt(5) D_opt(6)],[1  D_opt(7) D_opt(8) D_opt(9) D_opt(10) D_opt(11)],u1);
F_est=filter([X(1) X(2) X(3) X(4) X(5)],[1 X(6) X(7) X(8) X(9)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR5(X)
D_opt=[1 -0.4  -0.65  0.26 -0.77  -0.8498  0.6486];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) 0 D_opt(2) 0 D_opt(3) 0 D_opt(4)],[1 0 D_opt(5) 0 D_opt(6) 0 D_opt(7)],u1);
F_est=filter([X(1) 0 X(2) 0 X(3) 0 X(4)],[1 0 X(5) 0 X(6) 0 X(7)],u1);
o=1/L*sum((F-F_est).^2);
end

function o=IIR5R(X)
D_opt=[1 -0.4  -0.65  0.26 -0.77  -0.8498  0.6486 0 0 0 0];
L=200;
u1=wgn(L,1,0);
F=filter([D_opt(1) 0 D_opt(2) 0 D_opt(3) 0 D_opt(4)],[1 0 D_opt(5) 0 D_opt(6) 0 D_opt(7)],u1);
F_est=filter([X(1) X(2) X(3) X(4) X(5) X(6)],[1 X(7) X(8) X(9) X(10) X(11) ],u1);
o=1/L*sum((F-F_est).^2);
end
